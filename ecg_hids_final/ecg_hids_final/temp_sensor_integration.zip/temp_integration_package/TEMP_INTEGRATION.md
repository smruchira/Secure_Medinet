# Temperature Sensor (ESP32 + DS18B20) Integration

Adds a second, independent HIDS pipeline for a DS18B20 temperature
sensor on its **own ESP32** (separate MAC/IP from the ECG ESP32), with
its **own Random Forest model**, running **alongside** your existing
ECG pipeline without touching any of its code.

## What was added

```
cloud/
  main.py                    <- EDITED: added /predict_temp endpoint
                                 (ECG /predict untouched, same service)
  temp_attack_model.joblib   <- NEW: trained temp model (97.5% test acc)

edge/temp/                   <- NEW: everything temp-related, isolated
  temp_config.py             <- settings (env vars, see below)
  esp32_temp_listener.py     <- Flask server, port 5002, receives raw readings
  demo_temp_stream.py        <- fake live stream, for testing w/o hardware
  temp_orchestrator.py       <- watchdog -> cloud ML -> SDN enforcement
  temp_feature_extractor.py  <- raw readings -> 6 features
  temp_watchdog.py           <- local rule checks (range, rate, timeout)
  temp_privacy_strip.py      <- strips to cloud-safe fields
  temp_render_client.py      <- calls Render /predict_temp
  temp_logger.py             <- writes full_log_temp.jsonl (local, private)
  sdn_gateway_client.py      <- same SDN client code as edge/, reused as-is
  temp_attacks.py            <- 5 attack simulators, for synthetic data
  synthetic_temp.py          <- synthetic DS18B20 stream generator
  requirements.txt

training/temp/                <- NEW: offline dataset + training, not needed at runtime
  generate_temp_dataset.py
  train_temp_model.py
  (+ duplicated feature_extractor/attacks/logger/synthetic/config,
   same pattern as training/ already uses for ECG)
```

Nothing in `edge/*.py` (top level), `training/*.py` (top level), or the
ECG parts of `cloud/main.py` was changed.

## Architecture

```
ESP32 #1 (ECG)  ──POST /ecg_data (port 5000)──┐
                                                 ├─> RPi4
ESP32 #2 (DS18B20) ──POST /temp_data (port 5002)┘
                                                       |
                        full_log.jsonl           full_log_temp.jsonl
                              |                         |
                        orchestrator.py          temp_orchestrator.py
                              |                         |
                              v                         v
                   Render: POST /predict      Render: POST /predict_temp
                        (ecg model)                (temp model)
                              |                         |
                              └────────────┬────────────┘
                                            v
                               sdn_gateway_client.py
                           (same quarantine/rate_limit/
                            restore calls, by device MAC)
```

One Render service now serves two models. Two independent processes
run on the RPi4 for temperature (listener + orchestrator), parallel to
the two you already run for ECG — four terminals total, nothing shared
except the SDN gateway and (optionally) the log directory.

## 1. Redeploy the cloud API (one-time)

The Render service now needs `temp_attack_model.joblib` alongside the
existing `ecg_attack_model.joblib`. Both are already in `cloud/`.

Push the updated `cloud/` folder (new `main.py` + new `.joblib` file) to
whatever GitHub repo Render is building from, and it will redeploy
automatically. No `render.yaml` or `requirements.txt` changes needed —
same dependencies, same start command.

Verify after deploy:
```bash
curl https://your-app.onrender.com/health
# {"status":"ML API is running","models":{"ecg":"ecg_attack_model.joblib","temp":"temp_attack_model.joblib"}}
```

## 2. Wire up the DS18B20 ESP32

Your temperature ESP32 should POST each reading to the RPi4:

```
POST http://<rpi4-ip>:5002/temp_data
Content-Type: application/json

{
  "patient_id": "P001",
  "patient_name": "John Silva",
  "age": 45,
  "sex": "M",
  "location": "Colombo, Home",
  "device_mac": "11:22:33:44:55:66",
  "device_ip": "192.168.1.51",
  "raw_temp_value": 36.8,
  "timestamp": "2026-10-19T10:15:32Z"
}
```

One POST per DS18B20 reading (DS18B20 is slow — about 1 reading/sec at
12-bit resolution is typical). The listener buffers 30 readings
(~30s) per window before extracting features and logging, same
buffering pattern as the ECG listener.

## 3. Run it on the RPi4

Same `edge/requirements.txt` dependencies cover this (flask, requests,
numpy — no new system packages). Just also install the temp folder's
requirements (same three packages, listed for clarity):

```bash
cd edge/temp
pip install -r requirements.txt --break-system-packages

export RENDER_API_URL="https://your-app.onrender.com"      # same as ECG
export SDN_GATEWAY_URL="http://10.0.0.1:5000"               # same as ECG
```

Then, **in addition to** your existing two ECG terminals, run two more:

```bash
# Terminal 3: receive real DS18B20 data from its ESP32
python3 esp32_temp_listener.py

# (or, if testing without the temp hardware yet:)
python3 demo_temp_stream.py

# Terminal 4: the temperature detection pipeline
python3 temp_orchestrator.py
```

Your existing `python3 esp32_listener.py` / `orchestrator.py` for ECG
keep running exactly as they are, untouched.

## Configuration (env vars, all optional — sensible defaults apply)

| Variable | Purpose | Default |
|---|---|---|
| `RENDER_API_URL` | Same Render service as ECG | `https://cloud-ml-api.onrender.com` |
| `SDN_GATEWAY_URL` | Same SDN gateway as ECG | `http://10.0.0.1:5000` |
| `TEMP_DROP_CONFIDENCE_THRESHOLD` | Confidence above which to quarantine | `0.8` |
| `TEMP_RATE_LIMIT_CONFIDENCE_THRESHOLD` | Confidence above which to rate-limit | `0.5` |
| `TEMP_WATCHDOG_TIMEOUT_SEC` | Seconds of silence before a timeout alert | `30` |
| `MIN_PLAUSIBLE_TEMP_C` / `MAX_PLAUSIBLE_TEMP_C` | Watchdog plausibility range | `25` / `42` |
| `MAX_PLAUSIBLE_RATE_C` | Max realistic jump between consecutive samples | `2.0` |

`MIN/MAX_PLAUSIBLE_TEMP_C` assumes skin/body contact. If the DS18B20
is doing ambient/room monitoring instead, widen the range (e.g. `10`
to `45`).

## Privacy

Same design as ECG: only the 6 numeric features (`mean_temp_c`,
`temp_std_c`, `max_rate_of_change`, `signal_entropy`,
`sampling_gap_ms`, `is_duplicate_window`) ever leave the RPi4. Name,
patient ID, age, sex, location, device MAC/IP, and raw temperature
readings stay local in `full_log_temp.jsonl`.

## What counts as an "attack" here

Mirrors the ECG module's 5 categories, adapted to a DS18B20 stream:

- **sensor_spoofing** — flatlined, randomly-noisy, or spiked fake readings
- **firmware_tampering** — wrong calibration/gain, fixed offset, or clipped range
- **replay_attack** — an old window resent as if live
- **data_tampering** — implausible feature values that couldn't come from a real reading
- **device_masquerading** — plausible-looking values with inconsistent timing

## Retraining later

If you collect real (or more synthetic) temperature data:

```bash
cd training/temp
python3 generate_temp_dataset.py   # regenerate/expand the dataset
python3 train_temp_model.py        # retrain, saves temp_attack_model.joblib
```

Then copy the new `temp_attack_model.joblib` into `cloud/` and
redeploy (same as the ECG retraining workflow).
